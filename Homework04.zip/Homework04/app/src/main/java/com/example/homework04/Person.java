package com.example.homework04;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Person implements Parcelable {
    private String FirstName;
    private String LastName;
    private String Phone;
    private String Email;
    private String House;
    private String Street;
    private String Sangkat;
    private String Khan;
    private String City;

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getHouse() {
        return House;
    }

    public void setHouse(String house) {
        House = house;
    }

    public String getStreet() {
        return Street;
    }

    public void setStreet(String street) {
        Street = street;
    }

    public String getSangkat() {
        return Sangkat;
    }

    public void setSangkat(String sangkat) {
        Sangkat = sangkat;
    }

    public String getKhan() {
        return Khan;
    }

    public void setKhan(String khan) {
        Khan = khan;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public Person(String firstName, String lastName, String phone, String email, String house, String street, String sangkat, String khan, String city) {
        FirstName = firstName;
        LastName = lastName;
        Phone = phone;
        Email = email;
        House = house;
        Street = street;
        Sangkat = sangkat;
        Khan = khan;
        City = city;
    }

    protected Person(Parcel in) {
        FirstName = in.readString();
        LastName = in.readString();
        Phone = in.readString();
        Email = in.readString();
        House = in.readString();
        Street = in.readString();
        Sangkat = in.readString();
        Khan = in.readString();
        City = in.readString();
    }

    public static final Parcelable.Creator<Person> CREATOR = new Parcelable.Creator<Person>() {
        @Override
        public Person createFromParcel(Parcel in) {
            return new Person(in);
        }

        @Override
        public Person[] newArray(int size) {
            return new Person[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(FirstName);
        dest.writeString(LastName);
        dest.writeString(Phone);
        dest.writeString(Email);
        dest.writeString(House);
        dest.writeString(Street);
        dest.writeString(Sangkat);
        dest.writeString(Khan);
        dest.writeString(City);
    }

    @NonNull
    @Override
    public String toString() {
        return "First Name: " + FirstName + "\nLast Name: " + LastName +
                "\nPhone: " + Phone + "\nEmail: " + Email +
                "\nHouse: " + House + "\nStreet: " + Street +
                "\nSangkat: " + Sangkat + "\nKhan: " + Khan +
                "\nCity: " + City;
    }
}