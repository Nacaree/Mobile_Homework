package com.example.homework04;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void backClickHandler(View view) {

        TextInputEditText firstnameEditView = findViewById(R.id.FirstNameInputEditText);
        TextInputEditText lastnameEditView = findViewById(R.id.SurnameInputEditText);
        TextInputEditText phoneEditView = findViewById(R.id.PhoneInputEditText);
        TextInputEditText emailEditView = findViewById(R.id.EmailInputEditText);
        TextInputEditText houseEditView = findViewById(R.id.HouseInputEditText);
        TextInputEditText streetEditView = findViewById(R.id.StreetInputEditText);
        TextInputEditText sangkatEditView = findViewById(R.id.SangkatInputEditText);
        TextInputEditText khanEditView = findViewById(R.id.KhanInputEditText);
        TextInputEditText cityEditView = findViewById(R.id.CityInputEditText);

        String firstname = firstnameEditView.getText().toString();
        String lastname = lastnameEditView.getText().toString();
        String phone = phoneEditView.getText().toString();
        String email = emailEditView.getText().toString();
        String house = houseEditView.getText().toString();
        String street = streetEditView.getText().toString();
        String sangkat = sangkatEditView.getText().toString();
        String khan = khanEditView.getText().toString();
        String city = cityEditView.getText().toString();

        // Check if any required fields are empty
        if (firstname.isEmpty() || lastname.isEmpty()) {
            firstnameEditView.setError("Required");
            lastnameEditView.setError("Required");
            return; // Stop the function if required inputs are empty
        }

        // Create a Person object with the input data
        Person person = new Person(firstname, lastname, phone, email, house, street, sangkat, khan, city);

        // Prepare the data to send back
        Bundle bundle = new Bundle();
        bundle.putParcelable("person", person);
        Intent intent = new Intent();
        intent.putExtras(bundle);
        setResult(RESULT_OK, intent);
        finish();
    }
}