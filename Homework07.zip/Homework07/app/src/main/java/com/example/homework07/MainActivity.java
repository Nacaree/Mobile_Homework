package com.example.homework07;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.DialogFragment;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Exit Button
        Button exitButton = findViewById((R.id.exitButton));
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment exitDialog = new exitFragment();
                exitDialog.show(getSupportFragmentManager(), "exit Fragment");
            }
        });

        // Date Button
        Button dateButton = findViewById(R.id.dateButton);
        TextView displayTextView = findViewById(R.id.displayTextView);
        TextView liveTextView = findViewById((R.id.liveTextView));
        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Calendar cldr = Calendar.getInstance();
                int curDay = cldr.get(Calendar.DAY_OF_MONTH);
                int curMonth = cldr.get(Calendar.MONTH);
                int curYear = cldr.get(Calendar.YEAR);

                DatePickerDialog datePicker = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        // Display selected date
                        displayTextView.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                        // Calculate live days
                        calLiveDay(year, monthOfYear + 1, dayOfMonth);
                    }
                    private void calLiveDay(int year, int month, int dayOfMonth) {
                        int yearToDay;
                        int monthToDay;
                        int dayToDay;
                        int liveDay;
                        yearToDay = (curYear - year) * 365;
                        if (curMonth >= month) {
                            monthToDay = (curMonth - month) * 30;
                        } else {
                            monthToDay = ((curMonth - month) + 12) * 30 - 365;
                        }
                        dayToDay = curDay - dayOfMonth;
                        liveDay = yearToDay + monthToDay + dayToDay;
                        liveTextView.setText("Days Alive On this Earth: " + liveDay + " days");
                    }
                }, curYear, curMonth, curDay);
                datePicker.show();
                // Time Picker Button
                Button timePickerButton = (Button) findViewById(R.id.timeButton);
                timePickerButton.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        // Do something in response to button click
                        final Calendar cldr = Calendar.getInstance();
                        int hour = cldr.get(Calendar.HOUR_OF_DAY);
                        int minutes = cldr.get(Calendar.MINUTE);
                        // time picker dialog
                        TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker timePicker, int sHour, int sMinute) {
                                displayTextView.setText(sHour + ":" + sMinute);
                            }
                        }, hour, minutes, true);
                        timePickerDialog.show();
                    }
                });
            }
        });
    }
}

