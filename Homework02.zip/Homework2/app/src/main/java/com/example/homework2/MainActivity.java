package com.example.homework2;

import static java.lang.String.*;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        if (savedInstanceState != null) {
            EditText inputTempText = findViewById(R.id.inputTempEditNumber);
            TextView convertedText = findViewById(R.id.convertedTempTextView);

            inputTempText.setText(savedInstanceState.getString("inputTemp", ""));
            convertedText.setText(savedInstanceState.getString("convertedTemp", ""));
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @SuppressLint("DefaultLocale")
    private String convertToFh(String pCelsius){
        try{
            double c = Double.parseDouble(pCelsius);
            double f = c * (9.0/5.0) + 32.0;
            String format;
            format = format("%3.2f", f);
            return format;
        }catch(NumberFormatException nfe){
            return "Error";
        }
    }

    public void convertBtnListener(View v){
        EditText inputTempText = findViewById(R.id.inputTempEditNumber);
        TextView convertedText = findViewById(R.id.convertedTempTextView);
        String frStr = convertToFh(inputTempText.getText().toString());
        if (frStr.equals("Error")) {
            convertedText.setText(format("%s        ", frStr));
        } else {
            convertedText.setText(format("%s F", frStr));
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle state){
        EditText inputTempText = findViewById(R.id.inputTempEditNumber);
        TextView convertedText = findViewById(R.id.convertedTempTextView);
        state.putString("inputTemp", inputTempText.getText().toString());
        state.putString("convertedTemp", convertedText.getText().toString());
        super.onSaveInstanceState(state);
    }
}














