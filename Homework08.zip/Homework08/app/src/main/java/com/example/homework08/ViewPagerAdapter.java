package com.example.homework08;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.homework08.Fragments.EventFragment;
import com.example.homework08.Fragments.MovieFragment;
import com.example.homework08.Fragments.TicketFragment;

public class ViewPagerAdapter extends FragmentStateAdapter {
    public ViewPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return new MovieFragment(); // Movie fragment
            case 1:
                return new EventFragment(); // Example fragment
            case 2:
                return new TicketFragment(); // Example fragment
            default:
                return new MovieFragment();
        }
    }

    @Override
    public int getItemCount() {
        return 3; // Two tabs: Fruits & Animals
    }
}

