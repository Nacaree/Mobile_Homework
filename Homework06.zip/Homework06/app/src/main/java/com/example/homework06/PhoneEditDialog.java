package com.example.homework06;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class PhoneEditDialog extends DialogFragment {

    public interface PhoneEditListener {
        void onPhoneAdded(String name, String phoneNumber);

        void onPhoneUpdated(int id, String name, String phoneNumber);

        void onPhoneDeleted(int id);
    }

    private PhoneEditListener listener;
    private Integer PhoneId;
    private String PhoneName;
    private String PhoneNumber;

    public static final String TAG = "PhoneEditDialog";
    public static final String ARG_ID = "PhoneId";
    public static final String ARG_NAME = "PhoneName";
    public static final String ARG_PHONE_NUMBER = "PhoneNumber";

    public static PhoneEditDialog newInstance(Integer id, String name, String phoneNumber) {
        PhoneEditDialog fragment = new PhoneEditDialog();
        Bundle args = new Bundle();
        if (id != null) {
            args.putInt(ARG_ID, id);
        }
        if (name != null) {
            args.putString(ARG_NAME, name);
        }
        if (phoneNumber != null) {
            args.putString(ARG_PHONE_NUMBER, phoneNumber);
        }
        fragment.setArguments(args);
        return fragment;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_phone_edit, null);
        EditText nameEditText = dialogView.findViewById(R.id.dialog_name_edittext);
        EditText phoneEditText = dialogView.findViewById(R.id.dialog_phone_edittext);
        Button saveButton = dialogView.findViewById(R.id.dialog_save_button);
        Button deleteButton = dialogView.findViewById(R.id.dialog_delete_button);

        Bundle args = getArguments();
        if (args != null) {
            if (args.containsKey(ARG_ID)) PhoneId = args.getInt(ARG_ID);
            if (args.containsKey(ARG_NAME)) PhoneName = args.getString(ARG_NAME);
            if (args.containsKey(ARG_PHONE_NUMBER))
                PhoneNumber = args.getString(ARG_PHONE_NUMBER);
        }

        nameEditText.setText(PhoneName);
        phoneEditText.setText(PhoneNumber);

        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext()).setView(dialogView);

        if (PhoneId == null) {
            builder.setTitle("Add Phone");
            deleteButton.setVisibility(View.GONE);
            saveButton.setText(R.string.add);
        } else {
            builder.setTitle("Modify Phone");
            deleteButton.setVisibility(View.VISIBLE);
            saveButton.setText(R.string.update);
        }

        saveButton.setOnClickListener(v -> {
            String name = nameEditText.getText().toString();
            String phoneNumber = phoneEditText.getText().toString();
            if (PhoneId == null) {
                listener.onPhoneAdded(name, phoneNumber);
            } else {
                listener.onPhoneUpdated(PhoneId, name, phoneNumber);
            }
            dismiss();
        });

        deleteButton.setOnClickListener(v -> {
            // Show the confirmation dialog
            showDeleteConfirmationDialog();
        });

        return builder.create();
    }

    public void setPhoneEditListener(PhoneEditListener listener) {
        this.listener = listener;
    }

    private void showDeleteConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setMessage("Are you sure you want to delete this entry?").setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User confirmed the deletion
                if (PhoneId != null) {
                    listener.onPhoneDeleted(PhoneId);
                }
                dismiss(); // Dismiss the PhoneEditDialog
            }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // User cancelled the deletion
                dialog.dismiss(); // Dismiss the confirmation dialog
            }
        });
        builder.create().show();
    }

}