package com.example.homework06;

import android.database.Cursor;
import android.os.Bundle;

import androidx.cursoradapter.widget.SimpleCursorAdapter;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

public class PhoneListActivity extends AppCompatActivity implements PhoneEditDialog.PhoneEditListener {
    private DBManager dbManager;
    private SimpleCursorAdapter adapter;
    final String[] from = new String[]{DatabaseHelper._ID, DatabaseHelper.SUBJECT, DatabaseHelper.PHONE};
    final int[] to = new int[]{R.id.id, R.id.name, R.id.phone};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_emp_list);
        dbManager = new DBManager(this);
        dbManager.open();
        Cursor cursor = dbManager.fetch();
        ListView listView = findViewById(R.id.list_view);
        listView.setEmptyView(findViewById(R.id.empty));
        adapter = new SimpleCursorAdapter(this, R.layout.activity_view_record, cursor, from, to, 0);
        adapter.notifyDataSetChanged();
        listView.setAdapter(adapter);
// OnCLickListener For List Items
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long viewId) {
                TextView idTextView = view.findViewById(R.id.id);
                TextView nameTextView = view.findViewById(R.id.name);
                TextView phoneTextView = view.findViewById(R.id.phone);
                String id = idTextView.getText().toString();
                String name = nameTextView.getText().toString();
                String phone = phoneTextView.getText().toString();

                showModifyDialog(Integer.parseInt(id), name, phone);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.add_record) {
            showAddDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showAddDialog() {
        FragmentManager fm = getSupportFragmentManager();
        PhoneEditDialog phoneEditDialog = PhoneEditDialog.newInstance(null, null, null);
        phoneEditDialog.setPhoneEditListener(this);
        phoneEditDialog.show(fm, PhoneEditDialog.TAG);
    }

    private void showModifyDialog(int id, String name, String phone) {
        FragmentManager fm = getSupportFragmentManager();
        PhoneEditDialog phoneEditDialog = PhoneEditDialog.newInstance(id, name, phone);
        phoneEditDialog.setPhoneEditListener(this);
        phoneEditDialog.show(fm, PhoneEditDialog.TAG);
    }

    private void updateAdapter() {
        dbManager.open();
        Cursor cursor = dbManager.fetch();
        adapter.changeCursor(cursor);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onPhoneAdded(String name, String phoneNumber) {
        dbManager.insert(name, phoneNumber);
        updateAdapter();
    }

    @Override
    public void onPhoneUpdated(int id, String name, String phoneNumber) {
        dbManager.update(id, name, phoneNumber);
        updateAdapter();
    }

    @Override
    public void onPhoneDeleted(int id) {
        dbManager.delete(id);
        updateAdapter();
    }
}

